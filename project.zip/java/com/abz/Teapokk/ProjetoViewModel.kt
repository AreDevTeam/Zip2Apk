package com.abz.Teapokk

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.abz.Teapokk.engine.BuildEngine
import com.abz.Teapokk.model.Projeto
import com.abz.Teapokk.model.StatusProjeto
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ProjetoViewModel(application: Application) : AndroidViewModel(application) {

    // ─── Lista de projetos (Compose-observável) ───────────────────────────────
    val projetos = mutableStateListOf<Projeto>()

    // ─── Engine de build ──────────────────────────────────────────────────────
    private val buildEngine = BuildEngine(application)

    // ─── Log do build atual ───────────────────────────────────────────────────
    private val _buildLog = MutableStateFlow("")
    val buildLog: StateFlow<String> = _buildLog.asStateFlow()

    // ─── Projeto sendo buildado no momento ────────────────────────────────────
    private val _projetoEmBuild = MutableStateFlow<Projeto?>(null)
    val projetoEmBuild: StateFlow<Projeto?> = _projetoEmBuild.asStateFlow()

    // ─── Caminho do APK gerado ────────────────────────────────────────────────
    private val _apkGeradoPath = MutableStateFlow<String?>(null)
    val apkGeradoPath: StateFlow<String?> = _apkGeradoPath.asStateFlow()

    // ─────────────────────────────────────────────────────────────────────────
    // CRUD de Projetos
    // ─────────────────────────────────────────────────────────────────────────

    fun adicionarProjeto(
        nome: String,
        desc: String,
        versao: String,
        pacote: String,
        autor: String,
        zipUri: Uri?,
        fotoUri: Uri?
    ) {
        val novoProjeto = Projeto(
            nome = nome.trim(),
            desc = desc.trim(),
            versao = versao.trim(),
            pacote = pacote.trim(),
            autor = autor.trim(),
            zipUri = zipUri,
            fotoUri = fotoUri
        )
        projetos.add(novoProjeto)
    }

    fun removerProjeto(projeto: Projeto) {
        projetos.remove(projeto)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Build
    // ─────────────────────────────────────────────────────────────────────────

    fun iniciarBuild(projeto: Projeto) {
        viewModelScope.launch {
            // Atualiza status para BUILDANDO
            val idx = projetos.indexOf(projeto)
            if (idx >= 0) projetos[idx] = projeto.copy(status = StatusProjeto.BUILDANDO)

            _projetoEmBuild.value = projeto
            _buildLog.value = ""
            _apkGeradoPath.value = null

            // Coleta o log em tempo real
            buildEngine.buildApk(projeto).collect { evento ->
                when (evento) {
                    is BuildEngine.BuildEvento.Log -> {
                        _buildLog.value += evento.linha + "\n"
                    }
                    is BuildEngine.BuildEvento.Sucesso -> {
                        _apkGeradoPath.value = evento.apkPath
                        if (idx >= 0) projetos[idx] = projeto.copy(status = StatusProjeto.SUCESSO)
                        _projetoEmBuild.value = null
                    }
                    is BuildEngine.BuildEvento.Erro -> {
                        _buildLog.value += "\n❌ ERRO: ${evento.mensagem}\n"
                        if (idx >= 0) projetos[idx] = projeto.copy(status = StatusProjeto.ERRO)
                        _projetoEmBuild.value = null
                    }
                }
            }
        }
    }

    fun limparLog() {
        _buildLog.value = ""
        _apkGeradoPath.value = null
    }
}
