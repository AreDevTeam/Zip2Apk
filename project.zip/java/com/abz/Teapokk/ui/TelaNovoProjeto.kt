package com.abz.Teapokk.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.abz.Teapokk.ProjetoViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TelaNovoProjeto(
    viewModel: ProjetoViewModel,
    onVoltar: () -> Unit,
    onProjetoCriado: () -> Unit
) {
    // ─── Estado do formulário ─────────────────────────────────────────────────
    var nome    by remember { mutableStateOf("") }
    var desc    by remember { mutableStateOf("") }
    var versao  by remember { mutableStateOf("1.0") }
    var pacote  by remember { mutableStateOf("com.exemplo.app") }
    var autor   by remember { mutableStateOf("") }
    var zipUri  by remember { mutableStateOf<Uri?>(null) }
    var fotoUri by remember { mutableStateOf<Uri?>(null) }

    // ─── Erros de validação ───────────────────────────────────────────────────
    var erroNome   by remember { mutableStateOf(false) }
    var erroPacote by remember { mutableStateOf(false) }
    var erroZip    by remember { mutableStateOf(false) }

    // ─── File Pickers ─────────────────────────────────────────────────────────
    val pickerZip = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        zipUri = uri
        erroZip = false
    }

    val pickerFoto = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        fotoUri = uri
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Novo Projeto", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onVoltar) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ─── Seção: Informações do app ────────────────────────────────
            SecaoTitulo(icone = Icons.Filled.Info, titulo = "Informações do App")

            OutlinedTextField(
                value = nome,
                onValueChange = { nome = it; erroNome = false },
                label = { Text("Nome do Projeto *") },
                placeholder = { Text("Meu App Incrível") },
                isError = erroNome,
                supportingText = if (erroNome) { { Text("Campo obrigatório") } } else null,
                leadingIcon = { Icon(Icons.Filled.DriveFileRenameOutline, null) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = desc,
                onValueChange = { desc = it },
                label = { Text("Descrição") },
                placeholder = { Text("Breve descrição do projeto…") },
                leadingIcon = { Icon(Icons.Filled.Description, null) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
                maxLines = 4
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = versao,
                    onValueChange = { versao = it },
                    label = { Text("Versão *") },
                    leadingIcon = { Icon(Icons.Filled.Tag, null) },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = autor,
                    onValueChange = { autor = it },
                    label = { Text("Autor") },
                    leadingIcon = { Icon(Icons.Filled.Person, null) },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }

            OutlinedTextField(
                value = pacote,
                onValueChange = { pacote = it; erroPacote = false },
                label = { Text("Package Name *") },
                placeholder = { Text("com.empresa.app") },
                isError = erroPacote,
                supportingText = if (erroPacote) { { Text("Formato inválido (ex: com.exemplo.app)") } } else null,
                leadingIcon = { Icon(Icons.Filled.Code, null) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace)
            )

            // ─── Seção: Arquivos ──────────────────────────────────────────
            Spacer(Modifier.height(4.dp))
            SecaoTitulo(icone = Icons.Filled.FolderZip, titulo = "Arquivos")

            // File Picker — ZIP
            FilePickerBox(
                label = "Projeto Android (.zip) *",
                uri = zipUri,
                placeholder = "Selecionar arquivo .zip",
                icone = Icons.Filled.Archive,
                isError = erroZip,
                erroMsg = "Selecione o arquivo ZIP do projeto",
                onClick = { pickerZip.launch("application/zip") }
            )

            // File Picker — Foto/Ícone
            FilePickerBox(
                label = "Ícone do App (opcional)",
                uri = fotoUri,
                placeholder = "Selecionar imagem PNG/JPG",
                icone = Icons.Filled.Image,
                isError = false,
                erroMsg = "",
                onClick = { pickerFoto.launch("image/*") },
                previewUri = fotoUri
            )

            // ─── Botão de confirmar ───────────────────────────────────────
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    erroNome   = nome.isBlank()
                    erroPacote = !pacote.matches(Regex("^([a-zA-Z_][a-zA-Z0-9_]*\\.)+[a-zA-Z_][a-zA-Z0-9_]*\$"))
                    erroZip    = zipUri == null

                    if (!erroNome && !erroPacote && !erroZip) {
                        viewModel.adicionarProjeto(nome, desc, versao, pacote, autor, zipUri, fotoUri)
                        onProjetoCriado()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.AddCircle, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Criar Projeto", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Componentes auxiliares
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun SecaoTitulo(
    icone: androidx.compose.ui.graphics.vector.ImageVector,
    titulo: String
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icone, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(8.dp))
        Text(
            text = titulo,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
    }
    Divider(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
}

@Composable
private fun FilePickerBox(
    label: String,
    uri: Uri?,
    placeholder: String,
    icone: androidx.compose.ui.graphics.vector.ImageVector,
    isError: Boolean,
    erroMsg: String,
    onClick: () -> Unit,
    previewUri: Uri? = null
) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (isError) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .border(
                    width = 1.dp,
                    color = if (isError) MaterialTheme.colorScheme.error
                            else if (uri != null) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outline,
                    shape = RoundedCornerShape(10.dp)
                )
                .clickable(onClick = onClick)
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Miniatura de imagem (somente para o picker de foto)
            if (previewUri != null && uri != null) {
                AsyncImage(
                    model = uri,
                    contentDescription = "Ícone",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                )
                Spacer(Modifier.width(10.dp))
            } else {
                Icon(
                    imageVector = if (uri != null) Icons.Filled.CheckCircle else icone,
                    contentDescription = null,
                    tint = if (uri != null) MaterialTheme.colorScheme.primary
                           else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.width(10.dp))
            }

            Text(
                text = uri?.lastPathSegment?.let { "…/$it" } ?: placeholder,
                color = if (uri != null) MaterialTheme.colorScheme.onSurface
                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                fontSize = 14.sp,
                modifier = Modifier.weight(1f)
            )

            Icon(
                Icons.Filled.FolderOpen,
                contentDescription = "Selecionar",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }
        if (isError && erroMsg.isNotEmpty()) {
            Text(
                text = erroMsg,
                color = MaterialTheme.colorScheme.error,
                fontSize = 12.sp,
                modifier = Modifier.padding(start = 14.dp, top = 4.dp)
            )
        }
    }
}


