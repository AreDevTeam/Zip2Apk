package com.abz.Teapokk.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.abz.Teapokk.ProjetoViewModel

sealed class Tela(val rota: String) {
    object Lista      : Tela("lista")
    object NovoProjeto: Tela("novo_projeto")
    object BuildLog   : Tela("build_log/{projetoId}") {
        fun comId(id: Long) = "build_log/$id"
    }
}

@Composable
fun AppNavGraph(
    navController: NavHostController,
    viewModel: ProjetoViewModel
) {
    NavHost(navController = navController, startDestination = Tela.Lista.rota) {

        // ─── Tela inicial: lista de projetos ───────────────────────────────
        composable(Tela.Lista.rota) {
            TelaListaProjetos(
                viewModel = viewModel,
                onNovoProjeto = { navController.navigate(Tela.NovoProjeto.rota) },
                onIniciarBuild = { projeto ->
                    viewModel.iniciarBuild(projeto)
                    navController.navigate(Tela.BuildLog.comId(projeto.id))
                }
            )
        }

        // ─── Formulário: novo projeto ──────────────────────────────────────
        composable(Tela.NovoProjeto.rota) {
            TelaNovoProjeto(
                viewModel = viewModel,
                onVoltar = { navController.popBackStack() },
                onProjetoCriado = { navController.popBackStack() }
            )
        }

        // ─── Log do build ─────────────────────────────────────────────────
        composable(
            route = Tela.BuildLog.rota,
            arguments = listOf(navArgument("projetoId") { type = NavType.LongType })
        ) { backStackEntry ->
            val projetoId = backStackEntry.arguments?.getLong("projetoId") ?: 0L
            TelaBuildLog(
                projetoId = projetoId,
                viewModel = viewModel,
                onVoltar = { navController.popBackStack() }
            )
        }
    }
}
