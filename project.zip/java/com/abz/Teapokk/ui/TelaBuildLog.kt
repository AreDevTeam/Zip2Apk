package com.abz.Teapokk.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.abz.Teapokk.ProjetoViewModel
import com.abz.Teapokk.model.StatusProjeto
import java.io.File

// Paleta terminal
private val CorTerminal   = Color(0xFF1A1A2E)
private val CorTextoLog   = Color(0xFF00FF9C)
private val CorTextoEspec = Color(0xFFFFD700)
private val CorErro       = Color(0xFFFF5252)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TelaBuildLog(
    projetoId: Long,
    viewModel: ProjetoViewModel,
    onVoltar: () -> Unit
) {
    val context = LocalContext.current
    val buildLog       by viewModel.buildLog.collectAsState()
    val apkPath        by viewModel.apkGeradoPath.collectAsState()
    val projetoEmBuild by viewModel.projetoEmBuild.collectAsState()

    // Encontra o projeto na lista
    val projeto = viewModel.projetos.find { it.id == projetoId }
    val emBuild = projetoEmBuild?.id == projetoId

    // Auto-scroll para o fim do log
    val scrollState = rememberScrollState()
    LaunchedEffect(buildLog) {
        scrollState.animateScrollTo(scrollState.maxValue)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Build Log",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = projeto?.nome ?: "Projeto #$projetoId",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onVoltar) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
                actions = {
                    if (!emBuild && buildLog.isNotEmpty()) {
                        IconButton(onClick = { viewModel.limparLog() }) {
                            Icon(Icons.Filled.ClearAll, contentDescription = "Limpar log")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // ─── Barra de status do build ─────────────────────────────────
            BuildStatusBar(
                emBuild = emBuild,
                status = projeto?.status,
                apkPath = apkPath
            )

            // ─── Terminal de log ──────────────────────────────────────────
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(CorTerminal)
                    .padding(4.dp)
            ) {
                if (buildLog.isEmpty() && !emBuild) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            "Aguardando build…",
                            color = CorTextoLog.copy(alpha = 0.4f),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                } else {
                    Text(
                        text = buildLog,
                        color = CorTextoLog,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(scrollState)
                            .horizontalScroll(rememberScrollState())
                            .padding(12.dp)
                    )
                }
            }

            // ─── Ações pós-build ──────────────────────────────────────────
            if (apkPath != null) {
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Instalar APK
                        Button(
                            onClick = {
                                val apkFile = File(apkPath!!)
                                val apkUri = FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.fileprovider",
                                    apkFile
                                )
                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(apkUri, "application/vnd.android.package-archive")
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.tertiary
                            )
                        ) {
                            Icon(Icons.Filled.InstallMobile, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Instalar", fontWeight = FontWeight.SemiBold)
                        }

                        // Compartilhar APK
                        OutlinedButton(
                            onClick = {
                                val apkFile = File(apkPath!!)
                                val apkUri = FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.fileprovider",
                                    apkFile
                                )
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/vnd.android.package-archive"
                                    putExtra(Intent.EXTRA_STREAM, apkUri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(intent, "Compartilhar APK"))
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Share, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Compartilhar")
                        }
                    }
                }

                // Caminho do APK
                Surface(
                    color = Color.Black.copy(alpha = 0.7f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Filled.FolderOpen,
                            contentDescription = null,
                            tint = CorTextoEspec,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = apkPath ?: "",
                            color = CorTextoEspec,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BuildStatusBar(
    emBuild: Boolean,
    status: StatusProjeto?,
    apkPath: String?
) {
    val (cor, texto, mostrarProgress) = when {
        emBuild -> Triple(Color(0xFFFFA000), "⚙️  Build em andamento…", true)
        status == StatusProjeto.SUCESSO -> Triple(Color(0xFF43A047), "✅ Build concluído com sucesso!", false)
        status == StatusProjeto.ERRO    -> Triple(Color(0xFFE53935), "❌ Build falhou. Veja o log acima.", false)
        else                            -> Triple(Color(0xFF9E9E9E), "Aguardando build…", false)
    }

    Surface(color = cor.copy(alpha = 0.15f), modifier = Modifier.fillMaxWidth()) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = texto,
                    color = cor,
                    fontWeight = FontWeight.Medium,
                    fontSize = 14.sp,
                    modifier = Modifier.weight(1f)
                )
            }
            if (mostrarProgress) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = cor,
                    trackColor = cor.copy(alpha = 0.2f)
                )
            }
        }
    }
}
