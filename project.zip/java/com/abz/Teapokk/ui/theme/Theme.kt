package com.abz.Teapokk.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Paleta: tons de verde/ciano com fundo escuro (estilo IDE/terminal)
private val DarkColorScheme = darkColorScheme(
    primary          = Color(0xFF00E5FF),
    onPrimary        = Color(0xFF001F25),
    primaryContainer = Color(0xFF003544),
    onPrimaryContainer = Color(0xFF97F0FF),
    secondary        = Color(0xFF00FF9C),
    onSecondary      = Color(0xFF002114),
    secondaryContainer = Color(0xFF00391E),
    onSecondaryContainer = Color(0xFF8FFAB7),
    tertiary         = Color(0xFFFFB74D),
    onTertiary       = Color(0xFF211B00),
    tertiaryContainer = Color(0xFF312800),
    onTertiaryContainer = Color(0xFFFFDFA1),
    background       = Color(0xFF0D0D1A),
    onBackground     = Color(0xFFE0E0E0),
    surface          = Color(0xFF141425),
    onSurface        = Color(0xFFE0E0E0),
    surfaceVariant   = Color(0xFF1E1E35),
    onSurfaceVariant = Color(0xFFB0B0C0),
    outline          = Color(0xFF3A3A5C),
    outlineVariant   = Color(0xFF2A2A45),
    error            = Color(0xFFFF5252),
    onError          = Color(0xFF3A0000)
)

private val LightColorScheme = lightColorScheme(
    primary          = Color(0xFF006878),
    onPrimary        = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFB3EEFF),
    onPrimaryContainer = Color(0xFF001F25),
    secondary        = Color(0xFF006D41),
    onSecondary      = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFF8FFAB7),
    onSecondaryContainer = Color(0xFF002114),
    tertiary         = Color(0xFF795900),
    onTertiary       = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFFFDFA1),
    onTertiaryContainer = Color(0xFF251A00),
    background       = Color(0xFFF4FAFB),
    onBackground     = Color(0xFF161D1F),
    surface          = Color(0xFFFFFFFF),
    onSurface        = Color(0xFF161D1F)
)

@Composable
fun ApkBuilderZipTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.primaryContainer.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(),
        content = content
    )
}
