package com.abz.Teapokk.model

import android.net.Uri

/**
 * Modelo de dados representando um projeto Android a ser compilado.
 *
 * @param id         Identificador único gerado automaticamente (timestamp).
 * @param nome       Nome amigável do projeto.
 * @param desc       Descrição breve do projeto.
 * @param versao     Versão do app (ex: "1.0", "beta").
 * @param pacote     Package name Android (ex: "com.exemplo.app").
 * @param autor      Nome do desenvolvedor/autor.
 * @param zipUri     URI do arquivo .zip contendo o projeto Android.
 * @param fotoUri    URI da imagem usada como ícone do app (opcional).
 * @param status     Estado atual do projeto.
 */
data class Projeto(
    val id: Long = System.currentTimeMillis(),
    val nome: String,
    val desc: String,
    val versao: String,
    val pacote: String,
    val autor: String,
    val zipUri: Uri? = null,
    val fotoUri: Uri? = null,
    val status: StatusProjeto = StatusProjeto.AGUARDANDO
)

/**
 * Representa os possíveis estados de um projeto durante o ciclo de build.
 */
enum class StatusProjeto {
    AGUARDANDO,   // Projeto criado, aguardando build
    BUILDANDO,    // Build em execução
    SUCESSO,      // APK gerado com sucesso
    ERRO          // Falha durante o build
}
