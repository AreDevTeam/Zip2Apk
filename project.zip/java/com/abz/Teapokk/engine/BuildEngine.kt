package com.abz.Teapokk.engine

import android.content.Context
import android.os.Build
import android.os.Environment
import com.abz.Teapokk.model.Projeto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

/**
 * BuildEngine
 *
 * Responsável por:
 *  1. Descompactar o ZIP do projeto na pasta interna (filesDir).
 *  2. Tornar o gradlew executável.
 *  3. Executar ./gradlew assembleDebug via ProcessBuilder.
 *  4. Capturar stdout/stderr linha a linha e emitir via Flow.
 *  5. Copiar o APK gerado para /storage/emulated/0/Documents/ABZB/.
 *
 * AVISO IMPORTANTE:
 * Rodar ./gradlew assembleDebug dentro de um app Android é tecnicamente
 * possível, mas exige que o JAVA_HOME aponte para um JDK acessível no
 * dispositivo. Em ambiente rooteado ou em emulador customizado isso funciona.
 * Para uso em produção (CI), o GitHub Actions Workflow abaixo é a abordagem
 * recomendada e garante 100% de compatibilidade.
 */
class BuildEngine(private val context: Context) {

    // ─── Pasta de destino pública ─────────────────────────────────────────────
    companion object {
        const val PASTA_SAIDA = "ABZB"
        const val APK_DEBUG_REL = "app/build/outputs/apk/debug/app-debug.apk"
    }

    // ─── Eventos emitidos durante o build ────────────────────────────────────
    sealed class BuildEvento {
        data class Log(val linha: String) : BuildEvento()
        data class Sucesso(val apkPath: String) : BuildEvento()
        data class Erro(val mensagem: String) : BuildEvento()
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Ponto de entrada principal
    // ─────────────────────────────────────────────────────────────────────────
    fun buildApk(projeto: Projeto): Flow<BuildEvento> = flow {

        // 1. Valida URI do ZIP
        val zipUri = projeto.zipUri
            ?: run {
                emit(BuildEvento.Erro("Nenhum arquivo ZIP selecionado para o projeto '${projeto.nome}'."))
                return@flow
            }

        emit(BuildEvento.Log("═══════════════════════════════════════"))
        emit(BuildEvento.Log(" APK BUILDER ZIP — Build Iniciado"))
        emit(BuildEvento.Log(" Projeto : ${projeto.nome}"))
        emit(BuildEvento.Log(" Pacote  : ${projeto.pacote}"))
        emit(BuildEvento.Log(" Versão  : ${projeto.versao}"))
        emit(BuildEvento.Log(" Autor   : ${projeto.autor}"))
        emit(BuildEvento.Log("═══════════════════════════════════════\n"))

        // 2. Diretório de trabalho exclusivo para este projeto
        val projetoDir = File(context.filesDir, "builds/${projeto.id}")
        if (projetoDir.exists()) projetoDir.deleteRecursively()
        projetoDir.mkdirs()

        emit(BuildEvento.Log("📂 Pasta de build: ${projetoDir.absolutePath}"))

        // 3. Descompacta ZIP
        emit(BuildEvento.Log("\n🗜️  Descompactando ZIP..."))
        try {
            descompactarZip(zipUri, projetoDir)
            emit(BuildEvento.Log("✅ ZIP descompactado com sucesso.\n"))
        } catch (e: Exception) {
            emit(BuildEvento.Erro("Falha ao descompactar ZIP: ${e.message}"))
            return@flow
        }

        // 4. Localiza o diretório raiz do projeto Android dentro do ZIP
        val projetoRaiz = encontrarRaizProjeto(projetoDir)
            ?: run {
                emit(BuildEvento.Erro("Não foi possível encontrar settings.gradle ou settings.gradle.kts no ZIP."))
                return@flow
            }
        emit(BuildEvento.Log("📁 Raiz do projeto: ${projetoRaiz.absolutePath}\n"))

        // 5. Torna gradlew executável
        val gradlew = File(projetoRaiz, "gradlew")
        if (!gradlew.exists()) {
            emit(BuildEvento.Erro("gradlew não encontrado em ${projetoRaiz.absolutePath}"))
            return@flow
        }
        gradlew.setExecutable(true, false)
        emit(BuildEvento.Log("🔧 gradlew marcado como executável."))

        // 6. Monta ambiente (JAVA_HOME aponta para o JVM do Android Runtime)
        val javaHome = detectarJavaHome()
        emit(BuildEvento.Log("☕ JAVA_HOME detectado: $javaHome\n"))

        // 7. Executa ./gradlew assembleDebug
        emit(BuildEvento.Log("🔨 Executando: ./gradlew assembleDebug\n"))
        val sucesso = executarGradle(projetoRaiz, javaHome) { linha ->
            // Emitir cada linha do log (suspendemos direto no flow)
            // Usando trampoline para não bloquear o coletor
        }.also { logLines ->
            logLines.forEach { linha -> emit(BuildEvento.Log(linha)) }
        }

        // 8. Verifica se o APK foi gerado
        val apkOrigem = File(projetoRaiz, APK_DEBUG_REL)
        if (!apkOrigem.exists()) {
            emit(BuildEvento.Log("\n❌ APK não encontrado em: ${apkOrigem.absolutePath}"))
            emit(BuildEvento.Erro("Build falhou. Verifique os logs acima."))
            return@flow
        }

        emit(BuildEvento.Log("\n✅ APK gerado: ${apkOrigem.absolutePath}"))

        // 9. Copia APK para pasta pública
        val apkDestino = copiarApkParaDocuments(apkOrigem, projeto)
        emit(BuildEvento.Log("📦 APK copiado para: $apkDestino"))
        emit(BuildEvento.Log("\n🎉 Build concluído com sucesso!"))
        emit(BuildEvento.Sucesso(apkDestino))

    }.flowOn(Dispatchers.IO)

    // ─────────────────────────────────────────────────────────────────────────
    // Descompactador de ZIP
    // ─────────────────────────────────────────────────────────────────────────
    private fun descompactarZip(zipUri: android.net.Uri, destino: File) {
        val inputStream: InputStream = context.contentResolver.openInputStream(zipUri)
            ?: throw IllegalStateException("Não foi possível abrir o InputStream do URI: $zipUri")

        ZipInputStream(inputStream.buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val arquivo = File(destino, entry.name)

                // Proteção contra Zip Slip (path traversal)
                val canonicalPath = arquivo.canonicalPath
                if (!canonicalPath.startsWith(destino.canonicalPath + File.separator)) {
                    throw SecurityException("Entrada ZIP suspeita (Zip Slip): ${entry.name}")
                }

                if (entry.isDirectory) {
                    arquivo.mkdirs()
                } else {
                    arquivo.parentFile?.mkdirs()
                    FileOutputStream(arquivo).use { fos ->
                        zis.copyTo(fos, bufferSize = 8192)
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Encontra a pasta raiz do projeto Android (onde está o settings.gradle)
    // ─────────────────────────────────────────────────────────────────────────
    private fun encontrarRaizProjeto(base: File): File? {
        // BFS para encontrar settings.gradle[.kts]
        val fila = ArrayDeque<File>()
        fila.add(base)
        while (fila.isNotEmpty()) {
            val atual = fila.removeFirst()
            if (File(atual, "settings.gradle").exists() ||
                File(atual, "settings.gradle.kts").exists()
            ) return atual
            atual.listFiles()
                ?.filter { it.isDirectory }
                ?.forEach { fila.add(it) }
        }
        return null
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Detecta JAVA_HOME disponível no sistema
    // ─────────────────────────────────────────────────────────────────────────
    private fun detectarJavaHome(): String {
        // Tenta usar o Java embarcado no Android (disponível em emuladores/root)
        val candidatos = listOf(
            System.getProperty("java.home") ?: "",
            "/usr/lib/jvm/java-17-openjdk-amd64",
            "/usr/lib/jvm/java-11-openjdk-amd64",
            "/usr/lib/jvm/java-17-openjdk",
            "/data/data/com.termux/files/usr"
        )
        return candidatos.firstOrNull { it.isNotEmpty() && File(it).exists() }
            ?: (System.getProperty("java.home") ?: "")
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Executa o Gradle e retorna todas as linhas de log
    // ─────────────────────────────────────────────────────────────────────────
    private fun executarGradle(
        projetoDir: File,
        javaHome: String,
        onLinha: (String) -> Unit
    ): List<String> {
        val linhas = mutableListOf<String>()

        val pb = ProcessBuilder(
            "./gradlew",
            "assembleDebug",
            "--stacktrace",
            "--no-daemon",          // Essencial: daemon causa problemas em filesDir
            "--warning-mode", "all"
        ).apply {
            directory(projetoDir)
            redirectErrorStream(true) // Merge stderr → stdout

            // Configura variáveis de ambiente
            environment().apply {
                if (javaHome.isNotEmpty()) put("JAVA_HOME", javaHome)
                put("ANDROID_HOME", detectarAndroidHome())
                put("GRADLE_OPTS", "-Xmx2048m -Dorg.gradle.daemon=false")
                put("HOME", projetoDir.absolutePath)
                put("TMPDIR", File(context.cacheDir, "gradle_tmp").also { it.mkdirs() }.absolutePath)
            }
        }

        val processo = pb.start()

        // Lê stdout/stderr em tempo real
        processo.inputStream.bufferedReader().use { reader ->
            reader.lineSequence().forEach { linha ->
                linhas.add(linha)
                onLinha(linha)
            }
        }

        processo.waitFor()
        val exitCode = processo.exitValue()
        linhas.add("\n⚙️  Gradle finalizou com código de saída: $exitCode")

        return linhas
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Detecta ANDROID_HOME
    // ─────────────────────────────────────────────────────────────────────────
    private fun detectarAndroidHome(): String {
        val candidatos = listOf(
            System.getenv("ANDROID_HOME") ?: "",
            System.getenv("ANDROID_SDK_ROOT") ?: "",
            "${System.getenv("HOME")}/Android/Sdk",
            "/usr/local/lib/android/sdk"
        )
        return candidatos.firstOrNull { it.isNotEmpty() && File(it).exists() } ?: ""
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Copia o APK gerado para /storage/emulated/0/Documents/ABZB/
    // ─────────────────────────────────────────────────────────────────────────
    private fun copiarApkParaDocuments(apkOrigem: File, projeto: Projeto): String {
        val documentsDir = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+ — usa MediaStore ou pasta pública via Environment
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        } else {
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        }

        val pastaDestino = File(documentsDir, PASTA_SAIDA)
        pastaDestino.mkdirs()

        val nomeApk = "${projeto.nome.replace(" ", "_")}_v${projeto.versao}_debug.apk"
        val apkDestino = File(pastaDestino, nomeApk)

        apkOrigem.copyTo(apkDestino, overwrite = true)

        return apkDestino.absolutePath
    }
}
